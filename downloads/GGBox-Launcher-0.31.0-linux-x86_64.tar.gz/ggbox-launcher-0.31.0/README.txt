GGBox Launcher v0.31.0 (Linux x86_64)
=====================================
Kurulum:
1. Terminalde bu klasore gelin:
   chmod +x install.sh ggbox-launcher
2. Kurulumu baslatin:
   ./install.sh

Veya dogrudan `./ggbox-launcher` komutu ile portable olarak calistirabilirsiniz.

Gereksinimler (Debian/Ubuntu):
  sudo apt install libwebkit2gtk-4.1-0 libgtk-3-0
