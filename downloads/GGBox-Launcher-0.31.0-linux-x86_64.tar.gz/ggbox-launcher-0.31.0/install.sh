#!/bin/bash
set -e
echo "=========================================="
echo "  GGBox Launcher Linux Kurulum Sihirbazi  "
echo "=========================================="

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/512x512/apps"

mkdir -p "$BIN_DIR" "$DESKTOP_DIR" "$ICON_DIR"

echo "[1/3] Calistirilabilir dosya kopyalaniyor..."
cp "$DIR/ggbox-launcher" "$BIN_DIR/ggbox-launcher"
chmod +x "$BIN_DIR/ggbox-launcher"

echo "[2/3] Simgeler yukleniyor..."
cp "$DIR/icon.png" "$ICON_DIR/ggbox-launcher.png"

echo "[3/3] Masaustu kisayolu olusturuluyor..."
sed "s|Exec=ggbox-launcher|Exec=$BIN_DIR/ggbox-launcher|g" "$DIR/ggbox-launcher.desktop" > "$DESKTOP_DIR/ggbox-launcher.desktop"
chmod +x "$DESKTOP_DIR/ggbox-launcher.desktop"

# PATH kontrolu
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo "Bilgi: ~/.local/bin dizini PATH icinde degil. ~/.bashrc dosyaniza ekleyebilirsiniz:"
    echo '  export PATH="$HOME/.local/bin:$PATH"'
fi

echo "=========================================="
echo " Kurulum tamamlandi! GGBox Launcher hazir. "
echo " Uygulama menusunden veya terminalden 'ggbox-launcher' ile baslatabilirsiniz."
echo "=========================================="
